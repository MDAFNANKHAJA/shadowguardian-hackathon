# 🤖 JotaiChat Bot Configuration for ShadowGuardian

## Bot Type
- Conversational AI Assistant

## Training Source
- Uploaded custom Q&A text file
- Context-aware response mode enabled

## Features Enabled
- Emergency phrase detection
- Legal help suggestions
- Offline fallback suggestions
- Disguised UI setup

## Custom Integrations
- Emergency contact alerts (JotaiChat webhook support)
- PIN/voice authentication modules in premium setup

## Privacy Mode
- Bot name & theme disguised as journaling/chat bot
